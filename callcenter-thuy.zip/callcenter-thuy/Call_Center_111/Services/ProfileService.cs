﻿using Database.Model;
using Database.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services
{
    public class ProfileService : IProfileService
    {
        private IProfileRepository ProfileRepository { get; }
        public ProfileService(IProfileRepository repository)
        {
            ProfileRepository = repository;
        }

        public List<Profile> GetProfiles()
        {
            return ProfileRepository.GetProfile();
        }
        public Profile ProfileGetById(int profileid)
        {
            return ProfileRepository.ProfileGetById(profileid);
        }
        public Children GetChildren(int childrenid)
        {
            return ProfileRepository.GetChildren(childrenid);
        }
        public Province GetProvinceById(int provinceid)
        {
            return ProfileRepository.GetProvinceById(provinceid);
        }
        public District GetDistrictById(int districtid)
        {
            return ProfileRepository.GetDistrictById(districtid);
        }
        public Wards GetWardById(int wardid)
        {
            return ProfileRepository.GetWardById(wardid);
        }
        public List<Province> GetProvince()
        {
            return ProfileRepository.GetProvince();
        }
        public List<District> GetDistrict(int provinceid)
        {
            return ProfileRepository.GetDistrict(provinceid);
        }
        public List<Wards> GetWards(int districtid)
        {
            return ProfileRepository.GetWards(districtid);
        }
        public List<Profile> GetProfileSearch(string phonenumber)
        {
            return ProfileRepository.GetProfileSearch(phonenumber);
        }
        public bool UpdateProfile(int profileid, string phonenumber, string profilecontent, string profilestatus, int provinceid, int districtid, int wardsid)
        {
            return ProfileRepository.UpdateProfile(profileid, phonenumber, profilecontent, profilestatus, provinceid, districtid, wardsid);
        }
        public bool DeleteProfile(int profileid)
        {
            return ProfileRepository.DeleteProfile(profileid);
        }
        public int totalProfile()
        {
            return ProfileRepository.totalProfile();
        }
        public int numberPage(int totalProfile, int limit)
        {
            return ProfileRepository.numberPage(totalProfile, limit);
        }

        public IEnumerable<Profile> paginationProfile(int start, int limit)
        {
            return ProfileRepository.paginationProfile(start, limit);
        }
    }
}
