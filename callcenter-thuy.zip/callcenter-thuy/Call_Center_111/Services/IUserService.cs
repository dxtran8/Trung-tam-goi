﻿using Database.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services
{
    public interface IUserService
    {
        void CreateDatabase();
        User GetUser(string username, string password);
        User ChangePassword(string username, string new_password);
        List<User> list();
        bool KTraAccountName(string name);
        bool KtraRong(string name, string taikhoan, string matkhau);
        int Add(User user);
        bool Update(User user);
        bool Delete(User user);
        User GetUserById(int id);
        int totalUser();
        int numberPage(int totalUser, int limit);
        IEnumerable<User> paginationUser(int start, int limit);
        IEnumerable<User> TimUser(string chuoi);
        bool KTraTimKiem(string chuoi);
        IEnumerable<User> TimUserPage(string chuoi, int start, int limit);
        List<Permission> RoleDropDownList();
    }
}
