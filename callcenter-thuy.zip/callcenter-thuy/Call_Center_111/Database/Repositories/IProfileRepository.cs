﻿using Database.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Database.Repositories
{
    public interface IProfileRepository
    {
        List<Profile> GetProfile();
        Profile ProfileGetById(int profileid);
        Children GetChildren(int childrenid);
        Province GetProvinceById(int provinceid);
        District GetDistrictById(int districtid);
        Wards GetWardById(int wardid);
        List<Province> GetProvince();
        List<District> GetDistrict(int provinceid);
        List<Wards> GetWards(int districtid);
        List<Profile> GetProfileSearch(string phonenumber);
        bool InsertProfile(int profileid, string phonenumber, string profilecontent, string profilestatus, int createby);
        bool UpdateProfile(int profileid, string phonenumber, string profilecontent, string profilestatus, int provinceid, int districtid, int wardsid);
        bool DeleteProfile(int profileid);
        int totalProfile();
        int numberPage(int totalUser, int limit);
        IEnumerable<Profile> paginationProfile(int start, int limit);
    }
}
