﻿using Database.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Database.Repositories
{
    public class MyProfileRepository : IProfileRepository
    {
        private readonly DataContext DataContext = null;
        public MyProfileRepository(DataContext dataContext)
        {
            DataContext = dataContext;
        }
        public List<Profile> GetProfile()
        {
            return DataContext.Profiles.Where(x => x.IsDeleted == false).ToList();
        }
        public Profile ProfileGetById(int profileid)
        {
            var profile = DataContext.Profiles.SingleOrDefault(x => x.ProfileId == profileid);
            return profile;
        }
        public Children GetChildren(int childrenid)
        {
            var children = DataContext.Childrens.SingleOrDefault(x => x.ChildrenId == childrenid);
            return children;
        }
        public Province GetProvinceById(int provinceid)
        {
            var result = DataContext.Provinces.SingleOrDefault(x => x.ProvinceId == provinceid);
            return result;
        }
        public District GetDistrictById(int districtid)
        {
            var result = DataContext.Districts.SingleOrDefault(x => x.DistrictId == districtid);
            return result;
        }
        public Wards GetWardById(int wardid)
        {
            var result = DataContext.Wards.SingleOrDefault(x => x.WardsId == wardid);
            return result;
        }
        public List<Province> GetProvince()
        {
            var province = DataContext.Provinces.ToList();
            return province;
        }
        public List<District> GetDistrict(int provinceid)
        {
            var district = DataContext.Districts.Where(x => x.ProvinceId == provinceid).ToList();
            return district;
        }
        public List<Wards> GetWards(int districtid)
        {
            var ward = DataContext.Wards.Where(x => x.DistrictId == districtid).ToList();
            return ward;
        }
        public List<Profile> GetProfileSearch(string phonenumber)
        {
            var result = DataContext.Profiles.Where(x => x.PhoneNumber.Contains(phonenumber)).ToList();
            return result;
        }
        public bool InsertProfile(int profileid, string phonenumber, string profilecontent, string profilestatus, int createby)
        {
            Profile profile = new Profile();
            profile.ProfileId = profileid;
            profile.PhoneNumber = phonenumber;
            profile.CreateBy = createby;
            profile.Status = profilestatus;
            profile.CreateTime = DateTime.Now;
            DataContext.Profiles.Add(profile);
            DataContext.SaveChanges();
            return true;
        }
        public bool UpdateProfile(int profileid, string phonenumber, string profilecontent, string profilestatus, int provinceid, int districtid, int wardsid)
        {
            try
            {
                Profile result = DataContext.Profiles.Where(x => x.ProfileId == profileid).FirstOrDefault();
                if (result == null)
                    return false;
                else
                {
                    result.PhoneNumber = phonenumber;
                    result.ProblemContents = profilecontent;
                    result.Status = profilestatus;
                    result.UpdateTime = DateTime.Now;
                    result.ProvinceId = provinceid;
                    result.DistrictId = districtid;
                    result.WardsId = wardsid;
                    DataContext.Profiles.Update(result);
                    DataContext.SaveChanges();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
        public bool DeleteProfile(int profileid)
        {
            var result = DataContext.Profiles.Where(x => x.ProfileId == profileid).SingleOrDefault();
            if (result == null)
                return false;
            else
            {
                result.IsDeleted = true;
                DataContext.SaveChanges();
                return true;
            }
        }
        public int totalProfile()
        {
            return (from s in DataContext.Profiles where s.IsDeleted == false select s).ToList().Count;
        }
        public int numberPage(int totalProfile, int limit)
        {
            return (int)Math.Ceiling(totalProfile/(double)limit);
        }
        public IEnumerable<Profile> paginationProfile(int start, int limit)
        {
            var da = (from s in DataContext.Profiles where s.IsDeleted == false select s);
            var dataProfile = da.OrderByDescending(x => x.ProfileId).Skip(start).Take(limit);
            return dataProfile.ToList();
        }
    }
}
