﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace Call_Center_111.Controllers
{
    public class ProfileController : Controller
    {
        private readonly IProfileService _profileService;
        public HttpContext Current => new HttpContextAccessor().HttpContext;
        public ProfileController(IProfileService profileService)
        {
            _profileService = profileService;
        }
        public IActionResult Index(int? page=0) 
        {
            if (Current.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            int limit = 4; //số dòng trên 1 trang
            int start;
            if (page > 0)
            {
                page = page;// trang số
            }
            else
            {
                page = 1;
            }
            start = (int)(page - 1) * limit;// vị trí đầu tiên của trang có số trâng là page và hiện thị ra limit dòng

            ViewBag.pageCurrent = page;// số trang

            int totalProduct = _profileService.totalProfile(); // đếm tổng số danh sách

            ViewBag.totalProduct = totalProduct;// tỏng danh sách

            ViewBag.numberPage = _profileService.numberPage(totalProduct, limit);// có bao nhiêu trang

            var data = _profileService.paginationProfile(start, limit);
            return View(data);
        }
        public IActionResult UpdateProfile(int id)
        {
            if (Current.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            var result = _profileService.ProfileGetById(id);
            var children = _profileService.GetChildren((int)result.ChildrenId);
            var province = _profileService.GetProvinceById((int)(result.ProvinceId));
            var district = _profileService.GetDistrictById((int)(result.DistrictId));
            var ward = _profileService.GetWardById((int)result.WardsId);
            return View(result);
        }

        private IActionResult View(Database.Model.Profile result, Database.Model.Children children, Database.Model.Province province, Database.Model.District district, Database.Model.Wards ward)
        {
            throw new System.NotImplementedException();
        }

        [HttpPost]
        public IActionResult UpdateProfile(int id, string phone, string content, string Status, int province, int district, int ward)
        {
            var result = _profileService.UpdateProfile(id, phone, content, Status, province, district, ward);
            
            return RedirectToAction("Index","Profile");
        }
        public IActionResult DeleteProfile(int id)
        {
            if (Current.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            var result = _profileService.DeleteProfile(id);
            return RedirectToAction("Index");
        }
    }
}
