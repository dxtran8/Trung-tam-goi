﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services;

namespace Call_Center_111.ApiControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        private readonly IProfileService ProfileService = null;
        public AddressController(IProfileService profileService)
        {
            ProfileService = profileService;
        }
        [HttpGet]
        [Route("provinces")]
        public IActionResult GetProvince()
        {
            var provinces = ProfileService.GetProvince();
            return Ok(provinces);
        }
        [HttpGet]
        [Route("district")]
        public IActionResult GetDistrict(int provinceid)
        {
            var district = ProfileService.GetDistrict(provinceid);
            return Ok(district);
        }
        [HttpGet]
        [Route("ward")]
        public IActionResult GetWard(int districtid)
        {
            var wards = ProfileService.GetWards(districtid);
            return Ok(wards);
        }
    }
}
