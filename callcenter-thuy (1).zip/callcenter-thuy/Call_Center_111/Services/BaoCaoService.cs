﻿using Database.Model;
using Database.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services
{
    internal class BaoCaoService: IBaoCaoService
    {
        private IBaocaoRepository Repository { get; }
        public BaoCaoService(IBaocaoRepository res)
        {
            Repository = res;
        }
        public BaoCaoTheoTuoi Baocaotheotuoi(DateTime? batdau, DateTime? ketthuc)
        {
            return Repository.Baocaotheotuoi(batdau, ketthuc);
        }

        public BaoCaoTongHop Baocaotonghop(DateTime? batdau, DateTime? ketthuc)
        {
            return Repository.Baocaotonghop(batdau, ketthuc);
        }
    }
}
