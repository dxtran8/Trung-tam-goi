﻿using Database.Model;
using Database.Repositories;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services
{
    internal class TuVanService : ITuVanService
    {
        private readonly ITuVanRepository repository = null;
        public TuVanService (ITuVanRepository repository)
        {
            this.repository = repository;
        }
        public Advise GetAdviseById(int id)
        {
            return repository.GetAdviseById(id);
        }

        public int GetIdProfile(int id)
        {
           return repository.GetIdProfile(id);
        }

        public string GetSdt(int idProfile)
        {
            return repository.GetSdt(idProfile);
        }

        public IEnumerable<Advise> List()
        {
            return repository.List();
        }

        public List<Profile> ProfileRoleDropDownList()
        {
            return repository.ProfileRoleDropDownList();
        }

        public List<Permission> RoleDropDownList()
        {
            return repository.RoleDropDownList();
        }

        public bool SaveFile(IFormFile file)
        {
            return repository.SaveFile(file);
        }
    }
}
