﻿using Database.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services
{
    public interface IBaoCaoService
    {
        BaoCaoTheoTuoi Baocaotheotuoi(DateTime? batdau, DateTime? ketthuc);
        BaoCaoTongHop Baocaotonghop(DateTime? batdau, DateTime? ketthuc);
    }
}
