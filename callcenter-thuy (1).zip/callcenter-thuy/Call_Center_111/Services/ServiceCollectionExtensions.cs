﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services
{
    public static class ServiceCollectionExtensions
    {
        public static void UseMyService(this IServiceCollection services)
        {
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IProfileService, ProfileService>();
        }
        public static void BaocaoService(this IServiceCollection services)
        {
            services.AddScoped<IBaoCaoService, BaoCaoService>();
            services.AddScoped<ITuVanService, TuVanService>();
        }
    }
}
