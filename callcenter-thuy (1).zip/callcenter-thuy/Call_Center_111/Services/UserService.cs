﻿using Database.Model;
using Database.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services
{
    public class UserService : IUserService
    {
        private IUserRepository Repository { get; }
        public UserService(IUserRepository repository)
        {
            Repository = repository;
        }

        public User GetUser(string username, string password)
        {
            return Repository.GetUser(username, password);
            //throw new NotImplementedException();
        }

        public User ChangePassword(string username, string new_password)
        {
            return Repository.ChangePassword(username, new_password);
            //throw new NotImplementedException();
        }

        public void CreateDatabase()
        {
            Repository.CreateDatabase();
        }
        public List<User> list()
        {
            return Repository.list();
        }
        public int Add(User user)
        {
            return Repository.Add(user);
        }
        public bool Update(User user)
        {
            return Repository.Update(user);
        }
        public bool Delete(User user)
        {
            return Repository.Delete(user);
        }
        public User GetUserById(int id)
        {
            return Repository.GetUserById(id);
        }

        public List<Permission> RoleDropDownList()
        {
            return Repository.RoleDropDownList();
        }

        public int totalUser()
        {
            return Repository.totalUser();
        }

        public int numberPage(int totalUser, int limit)
        {
            return Repository.numberPage(totalUser, limit);
        }

        public IEnumerable<User> paginationUser(int start, int limit)
        {
            return Repository.paginationUser(start, limit);
        }

        public IEnumerable<User> TimUser(string chuoi)
        {
            return Repository.TimUser(chuoi);
        }

        public IEnumerable<User> TimUserPage(string chuoi, int start, int limit)
        {
            return Repository.TimUserPage(chuoi, start, limit);
        }

        public bool KTraAccountName(string name)
        {
            return Repository.KTraAccountName(name);
        }

        public bool KtraRong(string name, string taikhoan, string matkhau)
        {
            return Repository.KtraRong(name, taikhoan, matkhau);
        }

        public bool KTraTimKiem(string chuoi)
        {
            return Repository.KTraTimKiem(chuoi);
        }
    }
}
