﻿using System;

namespace Common
{
    public class Class1
    {
    }
}
