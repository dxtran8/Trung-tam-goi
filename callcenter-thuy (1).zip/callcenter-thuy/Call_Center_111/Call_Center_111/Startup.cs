using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Database;
using Services;
using Microsoft.AspNetCore.Http;
using Database.Repositories;

namespace Call_Center_111
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
<<<<<<< HEAD

        public void ConfigureServices(IServiceCollection services)
        {
            /*services.AddDbContext<DataContext>(options => options.UseSqlServer(@"
                Data Source=DESKTOP-THUY\SQLEXPRESS;
                Initial Catalog=dbCallCenter;
                Integrated Security=True"), ServiceLifetime.Scoped);*/
=======
        public void ConfigureServices(IServiceCollection services)
        {
>>>>>>> 5af60bcb012b6dfc8204e071c25e9ec831504d2f
            services.AddDbContext<DataContext>(options => options.UseSqlServer(@"
                Data Source=DESKTOP-THUY\SQLEXPRESS;
                Initial Catalog=dbCallCenter;
                Integrated Security=True"), ServiceLifetime.Scoped);

            //services.AddDbContext<DataContext>(options => options.UseSqlServer(@"
            //    Data Source=ADMIN;
            //    Initial Catalog=dbCallCenter;
            //    User ID=SA;Password=123456"), ServiceLifetime.Scoped);

            services.UseMyRepository();
            services.UseMyService();
            services.BaocaoRepository();
            services.BaocaoService();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromSeconds(10);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1",
                    new Microsoft.OpenApi.Models.OpenApiInfo
                    {
                        Title = "Demo API",
                        Description = "",
                        Version = "v1"
                    });
            });

            services.AddControllersWithViews();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseSwagger();
            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "Demo API");
            });

            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.UseSession();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=login}/{id?}");
            });
        }
    }
}
