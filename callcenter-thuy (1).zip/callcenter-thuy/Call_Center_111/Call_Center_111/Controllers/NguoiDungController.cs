﻿using Database.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Services;
using System;
using System.Linq;

namespace Call_Center_111.Controllers
{
    public class NguoiDungController : Controller
    {
        private readonly IUserService user;
        public HttpContext Current => new HttpContextAccessor().HttpContext;
        public NguoiDungController(IUserService _user)
        {
            user = _user;
        }
        public void SetRoleDropDownList(int? id = null)
        {
            ViewBag.DanhSachVaiTro = new SelectList(user.RoleDropDownList(), "PermissionId", "PermissionName", id);
        }
        public IActionResult Index(int? page, string searchString)
        {
            if (Current.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            if (!String.IsNullOrEmpty(searchString))
            {
                if (user.KTraTimKiem(searchString))
                {
                    if (page > 0)
                    {
                        page = page;// trang số
                    }
                    else
                    {
                        page = 1;
                    }
                    ViewBag.pageCurrent = page;// số trang
                    int totalProduct = user.TimUser(searchString).Count(); // đếm tổng số danh sách
                    int limit = totalProduct;
                    ViewBag.numberPage = 1;// có bao nhiêu trang
                    ViewBag.totalProduct = totalProduct;// tỏng danh sách
                    ViewBag.numberPage = user.numberPage(totalProduct, limit);// có bao nhiêu trang
                    var data = user.TimUser(searchString);
                    return View(data);
                }
                else
                {
                    TempData["thongbao"] = "Không tìm thấy người dùng nào";
                    return View();
                }


            }
            else
            {
                int limit = 6; //số dòng trên 1 trang
                int start;
                if (page > 0)
                {
                    page = page;// trang số
                }
                else
                {
                    page = 1;
                }
                start = (int)(page - 1) * limit;// vị trios đầu tiên của trang có số trâng là page và hiện thị ra limit dòng

                ViewBag.pageCurrent = page;// số trang

                int totalProduct = user.totalUser(); // đếm tổng số danh sách

                ViewBag.totalProduct = totalProduct;// tỏng danh sách

                ViewBag.numberPage = user.numberPage(totalProduct, limit);// có bao nhiêu trang

                var data = user.paginationUser(start, limit);
                return View(data);
            }
        }

        // GET: NguoiDungController/Create
        public IActionResult Create()
        {
            if (Current.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            SetRoleDropDownList();
            return View();
        }

        // POST: NguoiDungController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(User u)
        {
            if (user.KtraRong(u.UserName, u.Account, u.Password))
            {
                if (user.KTraAccountName(u.Account))
                {
                    try
                    {
                        user.Add(u);
                        TempData["thongbao"] = "Thêm mới thành công!  |^.^|";
                        return RedirectToAction("Index", "NguoiDung");
                    }
                    catch
                    {
                        TempData["thongbao"] = "Thêm mới thất bại vì lý do nào đó!  :(";
                        SetRoleDropDownList();
                        return View();
                    }
                }
                else
                {
                    TempData["thongbao"] = "Tên tài khoản đã được sử dụng, bạn hãy dùng tài khoản khác :)";
                    SetRoleDropDownList();
                    return View(u);
                }
            }
            else
            {
                TempData["thongbao"] = "Bạn chua nhập 1 trường dữ liệu nào đó!  :(";
                SetRoleDropDownList();
                return View();
            }

        }

        // GET: NguoiDungController/Edit/5
        public IActionResult Edit(int id)
        {
            if (Current.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            var u = user.GetUserById(id);
            SetRoleDropDownList(id);
            return View(u);
        }

        // POST: NguoiDungController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(User u)
        {
            try
            {
                if (user.Update(u))
                {
<<<<<<< HEAD
                    TempData["thongbao"] = "Sửa thành công!  |^.^|";
                    return RedirectToAction("Index", "NguoiDung");
=======
                    if (user.Update(u))
                    {
                        TempData["thongbao"] = "Sửa thành công!";
                        return RedirectToAction("Index", "NguoiDung");
                    }
                    else
                    {
                        SetRoleDropDownList(u.UserId);
                        TempData["thongbao"] = "Sửa thất bại!";
                        return View(u);
                    }
>>>>>>> 5af60bcb012b6dfc8204e071c25e9ec831504d2f
                }
                else
                {
<<<<<<< HEAD
=======
                    TempData["thongbao"] = "Sửa thất bại vì 1 lỗi nào đó!";
>>>>>>> 5af60bcb012b6dfc8204e071c25e9ec831504d2f
                    SetRoleDropDownList(u.UserId);
                    TempData["thongbao"] = "Sửa thất bại!     :(";
                    return View(u);
                }
            }

            catch
            {
<<<<<<< HEAD
                TempData["thongbao"] = "Sửa thất bại vì 1 lỗi nào đó!  :(";
=======
                TempData["thongbao"] = "Không được để trống dữ liệu";
>>>>>>> 5af60bcb012b6dfc8204e071c25e9ec831504d2f
                SetRoleDropDownList(u.UserId);
                return View(u);
            }
        }

        public IActionResult Delete(int id)
        {
            if (Current.Session.GetString("username") == null)
            {
                return RedirectToAction("Login", "Home");
            }
            var u = user.GetUserById(id);
            if (user.Delete(u))
            {
                TempData["thongbao"] = "Xóa thành công!";
                return RedirectToAction("Index", "NguoiDung");
            }
            else
            {
                TempData["thongbao"] = "Xóa thất bại";
                return RedirectToAction("Index", "NguoiDung");
            }
        }
    }
}

