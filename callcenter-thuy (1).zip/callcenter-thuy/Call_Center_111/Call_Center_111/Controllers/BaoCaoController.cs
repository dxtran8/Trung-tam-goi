﻿using Database.Model;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using Services;
using System;
using System.IO;

namespace Call_Center_111.Controllers
{
    public class BaoCaoController : Controller
    {
        private readonly IBaoCaoService baocao;
        public BaoCaoController(IBaoCaoService _baocao)
        {
            baocao = _baocao;
        }
        // GET: BaoCaoController
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult TongHop(DateTime? batdau, DateTime? ketthuc)
        {
            if (batdau == null || ketthuc == null)
            {
                return View();
            }
            else
            {
                var a = baocao.Baocaotonghop(batdau, ketthuc);
                return View(a);
            }
        }
        public IActionResult XuatTongHop(DateTime batdau, DateTime ketthuc, int DangMo, int DangXuLy, int DaXuLy)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var stream = new MemoryStream();
            using (var package = new ExcelPackage(stream))
            {
                var sheet = package.Workbook.Worksheets.Add("Bao cao tong hop");
                sheet.Cells[1, 1].Value = "Ngày bắt đầu: ";
                sheet.Cells[1, 2].Value = batdau.ToString("dd/MM/yyyy");
                sheet.Cells[1, 4].Value = "Ngày kết thúc:";
                sheet.Cells[1, 5].Value = ketthuc.ToString("dd/MM/yyyy");

                sheet.Cells[3, 1].Value = "Trạng thái";
                sheet.Cells[3, 2].Value = "Số lượng";
                sheet.Cells[4, 1].Value = "Đang mở";
                sheet.Cells[5, 1].Value = "Đang xử lý";
                sheet.Cells[6, 1].Value = "Đã xử lý";
                sheet.Cells[4, 2].Value = DangMo;
                sheet.Cells[5, 2].Value = DangXuLy;
                sheet.Cells[6, 2].Value = DaXuLy;
                package.Save();
            };
            stream.Position = 0;
            var filename = $"BaoCaoTongHop_{ DateTime.Now.ToString("yyyyMMddHHmmss")}.xlsx";
            return File(stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);

        }
        public ActionResult TheoTuoi(DateTime? batdau, DateTime? ketthuc)
        {
            if (batdau == null || ketthuc == null)
            {
                return View();
            }
            else
            {
                var a = baocao.Baocaotheotuoi(batdau, ketthuc);
                return View(a);
            }
        }
        public IActionResult XuatTheoTuoi(DateTime batdau, DateTime ketthuc, int DangMo013, int DangXuLy013, int DaXuLy013, int DangMo1415, int DangXuLy1415, int DaXuLy1415, int DangMo1617, int DangXuLy1617, int DaXuLy1617)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var stream = new MemoryStream();
            using (var package = new ExcelPackage(stream))
            {
                var sheet = package.Workbook.Worksheets.Add("Bao cao tong hop");
                sheet.Cells[1, 1].Value = "Ngày bắt đầu: ";
                sheet.Cells[1, 2].Value = batdau.ToString("dd/MM/yyyy");
                sheet.Cells[1, 4].Value = "Ngày kết thúc:";
                sheet.Cells[1, 5].Value = ketthuc.ToString("dd/MM/yyyy");

                sheet.Cells[3, 1].Value = "Trạng thái";
                sheet.Cells[3, 2].Value = "Tuổi từ 0-13";
                sheet.Cells[3, 3].Value = "Tuổi từ 14-15";
                sheet.Cells[3, 4].Value = "Tuổi từ 16-17";
                sheet.Cells[4, 1].Value = "Đang mở";
                sheet.Cells[5, 1].Value = "Đang xử lý";
                sheet.Cells[6, 1].Value = "Đã xử lý";
                sheet.Cells[4, 2].Value = DangMo013;
                sheet.Cells[5, 2].Value = DangXuLy013;
                sheet.Cells[6, 2].Value = DaXuLy013;
                sheet.Cells[4, 3].Value = DangMo1415;
                sheet.Cells[5, 3].Value = DangXuLy1415;
                sheet.Cells[6, 3].Value = DaXuLy1415;
                sheet.Cells[4, 4].Value = DangMo1617;
                sheet.Cells[5, 4].Value = DangXuLy1617;
                sheet.Cells[6, 4].Value = DaXuLy1617;
                package.Save();
            };
            stream.Position = 0;
            var filename = $"BaoCaoTheoTuoi_{ DateTime.Now.ToString("yyyyMMddHHmmss")}.xlsx";
            return File(stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", filename);

        }
    }
}
