﻿using Database.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Services;

namespace Call_Center_111.Controllers
{
    public class TuVanController : Controller
    {
        private readonly ITuVanService tuvan;
        public TuVanController(ITuVanService _tuvan)
        {
            tuvan = _tuvan;
        }
        public IActionResult Index()
        {
            return View(tuvan.List());
        }
        public IActionResult XemChiTiet(int id)
        {
           
            return View(tuvan.GetAdviseById(id));
        }
        [HttpGet]
        public IActionResult Them()
        {
                return View();
        }
        [HttpPost]
        public IActionResult Them(IFormFile file)
        {
            if (file == null)
            {
                return View();
            }
            else
            {
                if (tuvan.SaveFile(file))
                {
                    TempData["thongbao"] = "Thêm file thàng công";
                    return RedirectToAction("Index");
                }
                else
                {
                    TempData["thongbao"] = "Thêm file thất bại";
                    return View();
                }    
                   
            }
        }

    }
}
