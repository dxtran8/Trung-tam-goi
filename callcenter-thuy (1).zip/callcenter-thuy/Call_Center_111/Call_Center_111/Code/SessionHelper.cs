﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace Call_Center_111.Code
{
    public class SessionHelper
    {
        //public static void SetSession(UserSession session)
        //{
        //    HttpContext.Current.Session["loginSession"] = session;
        //}
        //public static UserSession GetSession()
        //{
        //    var session = HttpContext.Session["loginSession"];
        //    if (session == null)
        //    {
        //        return null;
        //    }
        //    else
        //    {
        //        return session as UserSession;
        //    }
        //}
    }
}