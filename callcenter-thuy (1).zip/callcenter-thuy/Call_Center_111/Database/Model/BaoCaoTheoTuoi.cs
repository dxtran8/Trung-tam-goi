﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Database.Model
{
    public class BaoCaoTheoTuoi //: IEntityTypeConfiguration<BaoCaoTheoTuoi>
    {
        public int DangMo013 { get; set; }
        public int DangXuLy013 { get; set; }
        public int DaXuLy013 { get; set; }
        public int DangMo1415 { get; set; }
        public int DangXuLy1415 { get; set; }
        public int DaXuLy1415 { get; set; }
        public int DangMo1617 { get; set; }
        public int DangXuLy1617 { get; set; }
        public int DaXuLy1617 { get; set; }
        public DateTime? Batdau { get; set; }
        public DateTime? KetThuc { get; set; }

        /*public int id { get; set; }
        public int DangMo013 { get; set; }
        public int DangXuLy013 { get; set; }
        public int DaXuLy013 { get; set; }
        public int DangMo1415 { get; set; }
        public int DangXuLy1415 { get; set; }
        public int DaXuLy1415 { get; set; }
        public int DangMo1617 { get; set; }
        public int DangXuLy1617 { get; set; }
        public int DaXuLy1617 { get; set; }
        public DateTime Batdau { get; set; }
        public DateTime KetThuc { get; set; }
        public DateTime createdTime { get; set; }
        public int? createdBy { get; set; }

        public void Configure(EntityTypeBuilder<BaoCaoTheoTuoi> builder)
        {
            builder.ToTable("BaoCaoTheoTuoi");
            builder.HasKey(x => x.id);
            builder.Property(x => x.DangMo013).HasColumnName("DangMo013").IsRequired(true);
            builder.Property(x => x.DangXuLy013).HasColumnName("DangXuLy013").IsRequired(true);
            builder.Property(x => x.DaXuLy013).HasColumnName("DaXuLy013").IsRequired(true);
            builder.Property(x => x.DangMo1415).HasColumnName("DangMo1415").IsRequired(true);
            builder.Property(x => x.DangXuLy1415).HasColumnName("DangXuLy1415").IsRequired(true);
            builder.Property(x => x.DaXuLy1415).HasColumnName("DaXuLy1415").IsRequired(true);
            builder.Property(x => x.DangMo1617).HasColumnName("DangMo1617").IsRequired(true);
            builder.Property(x => x.DangXuLy1617).HasColumnName("DangXuLy1617").IsRequired(true);
            builder.Property(x => x.DaXuLy1617).HasColumnName("DaXuLy1617").IsRequired(true);
            builder.Property(x => x.createdBy).HasColumnName("createdBy");

            builder.Property(a => a.Batdau).HasColumnName("Batdau").HasColumnType("date").IsRequired(true);
            builder.Property(a => a.KetThuc).HasColumnName("KetThuc").HasColumnType("date").IsRequired(false);
            builder.Property(a => a.createdTime).HasColumnName("createdTime").HasColumnType("date").HasDefaultValue(DateTime.Now);
        }*/


    }
}
