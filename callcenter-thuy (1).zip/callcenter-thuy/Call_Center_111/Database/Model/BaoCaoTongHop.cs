﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Database.Model
{
    public class BaoCaoTongHop //: IEntityTypeConfiguration<BaoCaoTongHop>
    {
        public int DangMo { get; set; }
        public int DangXuLy { get; set; }
        public int DaXuLy { get; set; }
        public DateTime? Batdau { get; set; }
        public DateTime? KetThuc { get; set; }

        /*public int id { get; set; }
        public int DangMo { get; set; }
        public int DangXuLy { get; set; }
        public int DaXuLy { get; set; }
        public DateTime Batdau { get; set; }
        public DateTime KetThuc { get; set; }
        public DateTime createdTime { get; set; }
        public int? createdBy { get; set; }
        public void Configure(EntityTypeBuilder<BaoCaoTongHop> builder)
        {
            builder.ToTable("BaoCaoTongHop");
            builder.HasKey(x => x.id);
            builder.Property(x => x.DangMo).HasColumnName("DangMo").IsRequired(true);
            builder.Property(x => x.DangXuLy).HasColumnName("DangXuLy").IsRequired(true);
            builder.Property(x => x.createdBy).HasColumnName("createdBy");

            builder.Property(a => a.Batdau).HasColumnName("Batdau").HasColumnType("date").IsRequired(true);
            builder.Property(a => a.KetThuc).HasColumnName("KetThuc").HasColumnType("date").IsRequired(false);
            builder.Property(a => a.DaXuLy).HasColumnName("DaXuLy").HasColumnType("int").IsRequired(true);
            builder.Property(a => a.createdTime).HasColumnName("createdTime").HasColumnType("date").HasDefaultValue(DateTime.Now);
        }*/
    }
}
