﻿using Database.Repository;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Database.Repositories
{
    public static class RepositoryCollectionExtensions
    {
        public static void UseMyRepository(this IServiceCollection services)
        {
            services.AddScoped<IUserRepository, MyUserRepository>();
            services.AddScoped<IProfileRepository, MyProfileRepository>();
        }
        public static void BaocaoRepository(this IServiceCollection services)
        {
            services.AddScoped<IBaocaoRepository, BaocaoRepository>();
            services.AddScoped<ITuVanRepository, TuVanRepository>();
        }
    }
}
