﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Database.Model;

namespace Database.Repository
{
    public class MyUserRepository : IUserRepository
    {
        private readonly DataContext Data = null;
        public MyUserRepository(DataContext dataContext)
        {
            Data = dataContext;
        }

        public User GetUser(string username, string password)
        {
            var result = Data.Users.Where(x=>x.Account==username && x.Password == password).FirstOrDefault();
            return result;
            //throw new NotImplementedException();
        }

        public User ChangePassword(string username, string new_password)
        {
            User user = Data.Users.Where(x=>x.Account == username).FirstOrDefault();
            user.Account = username;
            user.Password = new_password;
            Data.Users.Update(user);
            Data.SaveChanges();
            return user;
        }

        public void CreateDatabase()
        {
            Data.Database.EnsureCreated();
        }
        public List<User> list()
        {
            return (from s in Data.Users where s.IsDeleted == false select s).ToList();
        }
        public bool KtraRong(string name, string taikhoan, string matkhau)
        {
            if (name == null || taikhoan == null || matkhau == null)
            {
                return false;
            }
            else
                return true;
        }
        public bool KTraAccountName(string name)
        {
            var nameList = (from s in Data.Users select s.Account).ToList();
            foreach (var i in nameList)
            {
                if (name == i)
                {
                    return false;
                }
            }
            return true;
        }
        public int totalUser()
        {
            return (from s in Data.Users where s.IsDeleted == false select s).ToList().Count;
        }
        public int numberPage(int totalUser, int limit)
        {
            double numberpage = (double)totalUser / (double)limit;
            return (int)Math.Ceiling(numberpage);
        }
        public IEnumerable<User> paginationUser(int start, int limit)
        {
            var da = (from s in Data.Users where s.IsDeleted == false select s);
            var dataUser = da.OrderByDescending(x => x.UserId).Skip(start).Take(limit);
            return dataUser.ToList();
        }

        public int Add(User user)
        {
            Data.Users.Add(user);
            Data.SaveChanges();
            return user.UserId;
        }
        public User GetUserById(int id)
        {
            return Data.Users.SingleOrDefault(a => a.UserId == id);
        }
        public bool Update(User user)
        {
            try
            {
                var u = Data.Users.Find(user.UserId);
                u.UserName = user.UserName;
                u.Password = user.Password;
                u.UpdateTime = DateTime.Now;
                u.PermissionId = user.PermissionId;

                Data.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool Delete(User user)
        {
            try
            {
                var u = Data.Users.Find(user.UserId);
                u.IsDeleted = true;

                Data.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public IEnumerable<User> TimUser(string chuoi)
        {
            return Data.Users.Where(n => n.UserName.Contains(chuoi) || n.Account.Contains(chuoi) && n.IsDeleted == false);
        }
        public bool KTraTimKiem(string chuoi)
        {
            var da = Data.Users.Where(n => n.UserName.Contains(chuoi) || n.Account.Contains(chuoi) && n.IsDeleted == false).ToList().Count;
            if (da == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public IEnumerable<User> TimUserPage(string chuoi, int start, int limit)
        {
            var da = Data.Users.Where(n => n.UserName.Contains(chuoi) || n.Account.Contains(chuoi) && n.IsDeleted == false);
            var dataUser = da.OrderByDescending(x => x.UserId).Skip(start).Take(limit);
            return dataUser.ToList();
        }

        public List<Permission> RoleDropDownList()
        {
            return Data.Permissions.ToList();
        }
    }
}
