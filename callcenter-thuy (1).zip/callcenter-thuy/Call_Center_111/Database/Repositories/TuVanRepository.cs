﻿using Database.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Database.Repositories
{
    class TuVanRepository : ITuVanRepository
    {
        private readonly DataContext Data = null;

        public TuVanRepository(DataContext _data)
        {
            Data = _data;
        }
        public List<Permission> RoleDropDownList()
        {
            return Data.Permissions.ToList();
        }
        
        public Advise GetAdviseById(int id)
        {
            return Data.Advises.Find(id);
        }
        public int GetIdProfile(int id)
        {
            var i = (from s in Data.Advises where s.AdviseId == id select s.ProfileId).ToString();
            return int.Parse(i);
        }
        public string GetSdt(int idProfile)
        {
            var sdt = (from s in Data.Profiles where s.ProfileId == idProfile select s.PhoneNumber).Take(1).ToString();
            return sdt;
        }
        public IEnumerable<Advise> List()
        {
            return Data.Advises.Where(a => a.IsDeleted == false).ToList();
        }

        public bool SaveFile(IFormFile file)
        {
            try
            {
                var currentDir = Directory.GetCurrentDirectory();
                var info = Directory.CreateDirectory(currentDir + "\\wwwroot\\Audio");
                if(info.Exists)
                {
                    var saveFile = currentDir + "\\wwwroot\\Audio\\" + file.FileName;
                    using(StreamWriter writer = new StreamWriter(saveFile))
                    {
                        var strem = writer.BaseStream;
                        file.CopyTo(strem);
                        writer.Close();
                        return true;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<Profile> ProfileRoleDropDownList()
        {
            return Data.Profiles.ToList();
        }
    }
}
