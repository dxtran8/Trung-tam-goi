﻿using Database.Model;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Database.Repositories
{
    public class BaocaoRepository: IBaocaoRepository
    {
        private readonly DataContext Data = null;

        public BaocaoRepository(DataContext _data)
        {
            Data = _data;
        }
        public BaoCaoTongHop Baocaotonghop(DateTime? batdau, DateTime? ketthuc)
        {
            var a = Data.Profiles.Where(a => a.Status == "Đã xử lý" && a.CreateTime >= batdau && a.CreateTime <= ketthuc).Count();
            var b = Data.Profiles.Where(a => a.Status == "Đang xử lý" && a.CreateTime >= batdau && a.CreateTime <= ketthuc).Count();
            var c = Data.Profiles.Where(a => a.Status == "Đang mở" && a.CreateTime >= batdau && a.CreateTime <= ketthuc).Count();
            var tonghop = new BaoCaoTongHop();
            tonghop.DangMo = a;
            tonghop.DangXuLy = b;
            tonghop.DaXuLy = c;
            tonghop.Batdau = batdau;
            tonghop.KetThuc = ketthuc;
            return tonghop;

        }
        public BaoCaoTheoTuoi Baocaotheotuoi(DateTime? batdau, DateTime? ketthuc)
        {
            var Dang013 = (from a in Data.Profiles
                           from c in Data.Childrens
                           where a.ChildrenId == c.ChildrenId && a.Status == "Đang xử lý" &&
                           a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                           c.Age >= 0 && c.Age <= 13
                           select a.ChildrenId).ToList().Count;
            var Dang1415 = (from a in Data.Profiles
                            from c in Data.Childrens
                            where a.ChildrenId == c.ChildrenId && a.Status == "Đang xử lý" &&
                            a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                            c.Age >= 14 && c.Age <= 15
                            select a.ChildrenId).ToList().Count;
            var Dang1617 = (from a in Data.Profiles
                            from c in Data.Childrens
                            where a.ChildrenId == c.ChildrenId && a.Status == "Đang xử lý" &&
                            a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                            c.Age >= 16 && c.Age <= 17
                            select a.ChildrenId).ToList().Count;
            var da013 = (from a in Data.Profiles
                         from c in Data.Childrens
                         where a.ChildrenId == c.ChildrenId && a.Status == "Đã xử lý" &&
                         a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                         c.Age >= 0 && c.Age <= 13
                         select a.ChildrenId).ToList().Count;
            var da1415 = (from a in Data.Profiles
                          from c in Data.Childrens
                          where a.ChildrenId == c.ChildrenId && a.Status == "Đã xử lý" &&
                          a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                          c.Age >= 14 && c.Age <= 15
                          select a.ChildrenId).ToList().Count;
            var da1617 = (from a in Data.Profiles
                          from c in Data.Childrens
                          where a.ChildrenId == c.ChildrenId && a.Status == "Đã xử lý" &&
                          a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                          c.Age >= 16 && c.Age <= 17
                          select a.ChildrenId).ToList().Count;
            var mo013 = (from a in Data.Profiles
                         from c in Data.Childrens
                         where a.ChildrenId == c.ChildrenId && a.Status == "Đang mở" &&
                         a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                         c.Age >= 0 && c.Age <= 13
                         select a.ChildrenId).ToList().Count;
            var mo1415 = (from a in Data.Profiles
                          from c in Data.Childrens
                          where a.ChildrenId == c.ChildrenId && a.Status == "Đang mở" &&
                          a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                          c.Age >= 14 && c.Age <= 15
                          select a.ChildrenId).ToList().Count;
            var mo1617 = (from a in Data.Profiles
                          from c in Data.Childrens
                          where a.ChildrenId == c.ChildrenId && a.Status == "Đang mở" &&
                          a.CreateTime >= batdau && a.CreateTime <= ketthuc &&
                          c.Age >= 16 && c.Age <= 17
                          select a.ChildrenId).ToList().Count;
            var tuoi = new BaoCaoTheoTuoi();
            tuoi.DangMo013 = mo013;
            tuoi.DangMo1415 = mo1415;
            tuoi.DangMo1617 = mo1617;
            tuoi.DangXuLy013 = Dang013;
            tuoi.DangXuLy1415 = Dang1415;
            tuoi.DangXuLy1617 = Dang1617;
            tuoi.DaXuLy1617 = da1617;
            tuoi.DaXuLy013 = da013;
            tuoi.DaXuLy1415 = da1415;
            tuoi.Batdau = batdau;
            tuoi.KetThuc = ketthuc;
            return tuoi;
        }
        /*public void XuatBaocaoTongHop(BaoCaoTongHop baocao, DateTime batdau, DateTime ketthuc)
        {
            var stream = new MemoryStream();
            using (var package = new ExcelPackage(stream))
            {
                var sheet = package.Workbook.Worksheets.Add("Bao cao tong hop");
                sheet.Cells[1, 1].Value = "Ngày bắt đầu: ";
                sheet.Cells[1, 2].Value = batdau;
                sheet.Cells[1, 4].Value = "Ngày kết thúc:";
                sheet.Cells[1, 5].Value = ketthuc;

                sheet.Cells[3, 1].Value = "Trạng thái";
                sheet.Cells[3, 2].Value = "Số lượng";
                sheet.Cells[4, 1].Value = "Đang mở";
                sheet.Cells[5, 1].Value = "Đang xử lý";
                sheet.Cells[6, 1].Value = "Đã xử lý";
                sheet.Cells[4, 2].Value = baocao.DangMo;
                sheet.Cells[5, 2].Value = baocao.DangXuLy;
                sheet.Cells[6, 2].Value = baocao.DaXuLy;
                package.Save();
            };
            stream.Position = 0;
            var filename = $"BaoCaoTongHop_{ DateTime.Now.ToString("yyyyMMddHHmmss")}.xlsx";
            return FileInfo(stream, "application/vnd.openxmlformats-oficedocument.spreadsheetml.sheet", filename);
        }*/
    }
}
