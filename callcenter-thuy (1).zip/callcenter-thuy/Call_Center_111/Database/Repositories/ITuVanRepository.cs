﻿using Database.Model;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace Database.Repositories
{
    public interface ITuVanRepository
    {
        IEnumerable<Advise> List();
        Advise GetAdviseById (int id);
        bool SaveFile(IFormFile file);
        List<Permission> RoleDropDownList();
        List<Profile> ProfileRoleDropDownList();
        int GetIdProfile(int id);
        string GetSdt(int idProfile);
    }
}
